import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { useAuth } from "@/hooks/useAuth";
import { BrandMark } from "@/components/AppHeader";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — Talk-to-Learn" },
      {
        name: "description",
        content: "Create your Talk-to-Learn account and start learning by talking to an AI tutor.",
      },
      { property: "og:title", content: "Sign in — Talk-to-Learn" },
      { property: "og:description", content: "Start learning by talking to an AI tutor." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const { session, loading } = useAuth();
  const [mode, setMode] = useState<"signin" | "signup">("signup");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!loading && session) navigate({ to: "/" });
  }, [loading, session, navigate]);

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin },
        });
        if (error) throw error;
        toast.success("Account created. Check your email if confirmation is required.");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Something went wrong");
    } finally {
      setBusy(false);
    }
  }

  async function handleGoogle() {
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      toast.error("Google sign-in didn't work. Try email instead.");
      return;
    }
  }

  return (
    <main className="grid min-h-screen place-items-center bg-paper px-5 py-10">
      <div className="w-full max-w-md">
        <div className="flex items-center gap-3">
          <BrandMark />
          <div>
            <p className="font-display text-xl font-bold tracking-tight">Talk-to-Learn</p>
            <p className="font-mono text-[11px] text-muted-foreground">
              Don&apos;t study. Have a conversation.
            </p>
          </div>
        </div>

        <div className="mt-7 rounded-3xl bg-card p-6 outline outline-line">
          <h1 className="font-display text-2xl font-bold tracking-tight">
            {mode === "signup" ? "Create your account" : "Welcome back"}
          </h1>
          <p className="mt-1 text-sm text-ink-soft">
            Your tutor remembers your progress across sessions.
          </p>

          <form onSubmit={handleSubmit} className="mt-5 space-y-3">
            <div>
              <label htmlFor="email" className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
                Email
              </label>
              <input
                id="email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-1 w-full rounded-xl bg-paper-2 px-4 py-3 text-sm outline-none ring-brand/40 focus:ring-2"
                placeholder="you@example.com"
              />
            </div>
            <div>
              <label htmlFor="password" className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
                Password
              </label>
              <input
                id="password"
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="mt-1 w-full rounded-xl bg-paper-2 px-4 py-3 text-sm outline-none ring-brand/40 focus:ring-2"
                placeholder="At least 6 characters"
              />
            </div>
            <button
              type="submit"
              disabled={busy}
              className="w-full rounded-full bg-brand py-3.5 font-display text-sm font-semibold text-paper shadow-lg shadow-brand/20 disabled:opacity-60"
            >
              {busy ? "One moment…" : mode === "signup" ? "Create account" : "Sign in"}
            </button>
          </form>

          <button
            type="button"
            onClick={handleGoogle}
            className="mt-3 w-full rounded-full bg-paper-2 py-3.5 font-display text-sm font-semibold text-ink"
          >
            Continue with Google
          </button>

          <p className="mt-5 text-center text-sm text-ink-soft">
            {mode === "signup" ? "Already have an account?" : "New here?"}{" "}
            <button
              type="button"
              onClick={() => setMode(mode === "signup" ? "signin" : "signup")}
              className="font-semibold text-brand"
            >
              {mode === "signup" ? "Sign in" : "Create one"}
            </button>
          </p>
        </div>
      </div>
    </main>
  );
}
