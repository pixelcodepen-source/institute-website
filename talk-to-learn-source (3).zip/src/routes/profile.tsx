import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { AppHeader } from "@/components/AppHeader";
import { BottomNav } from "@/components/BottomNav";
import { profileQuery } from "@/lib/data";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Your tutor & profile — Talk-to-Learn" },
      {
        name: "description",
        content:
          "Choose your tutor's personality, daily study time and level, or sign out of Talk-to-Learn.",
      },
      { property: "og:title", content: "Your tutor & profile — Talk-to-Learn" },
      { property: "og:description", content: "Pick your tutor style and daily study time." },
    ],
  }),
  component: ProfilePage,
});

const personalities = [
  "Friendly Teacher",
  "Strict Professor",
  "Patient Tutor",
  "Socratic Tutor",
  "Study Buddy",
];
const levels = ["Beginner", "Intermediate", "Advanced"];
const minutes = [10, 20, 30, 45];

function ProfilePage() {
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const queryClient = useQueryClient();
  const [name, setName] = useState("");

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  const { data: profile } = useQuery({ ...profileQuery(user?.id ?? ""), enabled: !!user });

  useEffect(() => {
    if (profile?.display_name) setName(profile.display_name);
  }, [profile?.display_name]);

  async function save(patch: Record<string, unknown>) {
    if (!user) return;
    const { error } = await supabase.from("profiles").update(patch).eq("id", user.id);
    if (error) {
      toast.error(error.message);
      return;
    }
    await queryClient.invalidateQueries({ queryKey: ["profile", user.id] });
    toast.success("Saved");
  }

  return (
    <main className="min-h-screen bg-paper pb-28 text-ink">
      <div className="mx-auto max-w-6xl px-6 py-8 lg:px-10">
        <AppHeader streak={profile?.streak_days} badge={profile?.level} />

        <section className="mt-9 rounded-3xl bg-card p-6 outline outline-line">
          <h1 className="font-display text-xl font-bold tracking-tight">Your profile</h1>
          <div className="mt-4 flex gap-2">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name"
              className="flex-1 rounded-xl bg-paper-2 px-4 py-3 text-sm outline-none ring-brand/40 focus:ring-2"
            />
            <button
              type="button"
              onClick={() => save({ display_name: name })}
              className="rounded-full bg-brand px-5 font-display text-sm font-semibold text-paper"
            >
              Save
            </button>
          </div>
          <p className="mt-3 font-mono text-[11px] text-muted-foreground">{user?.email}</p>
        </section>

        <section className="mt-6 rounded-3xl bg-card p-6 outline outline-line">
          <h2 className="font-display text-lg font-semibold tracking-tight">Tutor personality</h2>
          <p className="mt-1 text-sm text-ink-soft">
            Same accurate teaching — a different way of talking to you.
          </p>
          <div className="mt-4 grid gap-2 sm:grid-cols-2">
            {personalities.map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => save({ tutor_personality: option })}
                className={`rounded-xl px-4 py-3 text-left text-sm font-medium ${
                  profile?.tutor_personality === option ? "bg-brand text-paper" : "bg-paper-2 text-ink"
                }`}
              >
                {option}
              </button>
            ))}
          </div>
        </section>

        <section className="mt-6 grid gap-6 sm:grid-cols-2">
          <div className="rounded-3xl bg-card p-6 outline outline-line">
            <h2 className="font-display text-lg font-semibold tracking-tight">Level</h2>
            <div className="mt-4 grid gap-2">
              {levels.map((option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => save({ level: option })}
                  className={`rounded-xl px-4 py-3 text-left text-sm font-medium ${
                    profile?.level === option ? "bg-brand text-paper" : "bg-paper-2 text-ink"
                  }`}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
          <div className="rounded-3xl bg-card p-6 outline outline-line">
            <h2 className="font-display text-lg font-semibold tracking-tight">Daily time</h2>
            <div className="mt-4 grid grid-cols-2 gap-2">
              {minutes.map((option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => save({ daily_minutes: option })}
                  className={`rounded-xl px-4 py-3 text-sm font-medium ${
                    profile?.daily_minutes === option ? "bg-brand text-paper" : "bg-paper-2 text-ink"
                  }`}
                >
                  {option} min
                </button>
              ))}
            </div>
          </div>
        </section>

        <button
          type="button"
          onClick={async () => {
            await supabase.auth.signOut();
            navigate({ to: "/auth" });
          }}
          className="mt-6 w-full rounded-full bg-paper-2 py-3.5 font-display text-sm font-semibold text-ink"
        >
          Sign out
        </button>
      </div>
      <BottomNav />
    </main>
  );
}
