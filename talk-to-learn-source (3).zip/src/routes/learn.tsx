import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { AppHeader } from "@/components/AppHeader";
import { BottomNav } from "@/components/BottomNav";
import { coursesQuery, profileQuery } from "@/lib/data";
import { generatePlan } from "@/lib/tutor.functions";

export const Route = createFileRoute("/learn")({
  head: () => ({
    meta: [
      { title: "Choose a subject — Talk-to-Learn" },
      {
        name: "description",
        content:
          "Pick a subject or type your own, and your AI tutor builds a conversational course around it.",
      },
      { property: "og:title", content: "Choose a subject — Talk-to-Learn" },
      { property: "og:description", content: "Pick a subject and start a voice lesson." },
    ],
  }),
  component: LearnPage,
});

const subjects = [
  "Mathematics",
  "Physics",
  "Chemistry",
  "Biology",
  "History",
  "Geography",
  "English",
  "Programming",
  "Economics",
  "Business",
  "General Knowledge",
];

function LearnPage() {
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const queryClient = useQueryClient();
  const makePlan = useServerFn(generatePlan);
  const [custom, setCustom] = useState("");
  const [busy, setBusy] = useState<string | null>(null);

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  const { data: profile } = useQuery({ ...profileQuery(user?.id ?? ""), enabled: !!user });
  const { data: courses } = useQuery({ ...coursesQuery(user?.id ?? ""), enabled: !!user });

  async function startSubject(subject: string) {
    if (!user) return;
    setBusy(subject);
    try {
      const existing = courses?.find((c) => c.subject.toLowerCase() === subject.toLowerCase());
      if (existing) {
        navigate({ to: "/lesson/$courseId", params: { courseId: existing.id } });
        return;
      }
      const level = profile?.level ?? "Beginner";
      const { topics } = await makePlan({ data: { subject, level, goal: profile?.goal ?? null } });
      const { data: course, error } = await supabase
        .from("courses")
        .insert({ user_id: user.id, subject, level, goal: profile?.goal ?? null })
        .select()
        .single();
      if (error) throw error;
      await supabase.from("topics").insert(
        topics.map((name, index) => ({
          course_id: course.id,
          user_id: user.id,
          name,
          position: index,
          status: index === 0 ? "in_progress" : "locked",
        })),
      );
      await queryClient.invalidateQueries({ queryKey: ["courses", user.id] });
      navigate({ to: "/lesson/$courseId", params: { courseId: course.id } });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not start that subject");
    } finally {
      setBusy(null);
    }
  }

  return (
    <main className="min-h-screen bg-paper pb-28 text-ink">
      <div className="mx-auto max-w-6xl px-6 py-8 lg:px-10">
        <AppHeader streak={profile?.streak_days} badge={profile?.level} />

        <section className="mt-9 rounded-3xl bg-card p-6 outline outline-line">
          <h1 className="font-display text-2xl font-bold tracking-tight">What shall we talk about?</h1>
          <p className="mt-1 text-sm text-ink-soft">
            Pick a subject, or type anything — your tutor will build a plan around it.
          </p>

          <div className="mt-5 flex gap-2">
            <input
              value={custom}
              onChange={(e) => setCustom(e.target.value)}
              placeholder="I want to learn quantum mechanics"
              className="flex-1 rounded-xl bg-paper-2 px-4 py-3 text-sm outline-none ring-brand/40 focus:ring-2"
            />
            <button
              type="button"
              disabled={custom.trim().length < 2 || busy !== null}
              onClick={() => startSubject(custom.trim())}
              className="rounded-full bg-brand px-6 font-display text-sm font-semibold text-paper disabled:opacity-50"
            >
              Start
            </button>
          </div>

          <div className="mt-6 flex flex-wrap gap-2">
            {subjects.map((subject) => (
              <button
                key={subject}
                type="button"
                disabled={busy !== null}
                onClick={() => startSubject(subject)}
                className="rounded-full bg-paper-2 px-4 py-2.5 text-sm font-medium text-ink transition-colors hover:bg-brand hover:text-paper disabled:opacity-50"
              >
                {busy === subject ? "Building…" : subject}
              </button>
            ))}
          </div>
        </section>

        {courses && courses.length > 0 ? (
          <section className="mt-6 rounded-3xl bg-card p-6 outline outline-line">
            <h2 className="font-display text-lg font-semibold tracking-tight">Your courses</h2>
            <div className="mt-4 space-y-2.5">
              {courses.map((course) => (
                <button
                  key={course.id}
                  type="button"
                  onClick={() => navigate({ to: "/lesson/$courseId", params: { courseId: course.id } })}
                  className="flex w-full items-center justify-between rounded-xl bg-paper-2 px-4 py-3 text-left"
                >
                  <span className="text-sm font-medium">{course.subject}</span>
                  <span className="font-mono text-xs text-muted-foreground">{course.progress}%</span>
                </button>
              ))}
            </div>
          </section>
        ) : null}
      </div>
      <BottomNav />
    </main>
  );
}
