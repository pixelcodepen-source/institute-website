import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { BrandMark } from "@/components/AppHeader";
import { generatePlan } from "@/lib/tutor.functions";

export const Route = createFileRoute("/onboarding")({
  head: () => ({
    meta: [
      { title: "Set up your plan — Talk-to-Learn" },
      {
        name: "description",
        content: "Tell your AI tutor what you want to learn and get a personalised learning plan.",
      },
      { property: "og:title", content: "Set up your plan — Talk-to-Learn" },
      { property: "og:description", content: "Get a personalised conversational learning plan." },
    ],
  }),
  component: Onboarding,
});

const levels = ["Beginner", "Intermediate", "Advanced"];
const styles = ["Examples first", "Step by step", "Question me", "Real-world stories"];
const minutes = [10, 20, 30, 45];

function Onboarding() {
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const makePlan = useServerFn(generatePlan);

  const [step, setStep] = useState(0);
  const [subject, setSubject] = useState("");
  const [level, setLevel] = useState("Beginner");
  const [goal, setGoal] = useState("");
  const [daily, setDaily] = useState(20);
  const [style, setStyle] = useState(styles[0]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  async function finish() {
    if (!user) return;
    setBusy(true);
    try {
      const { topics } = await makePlan({ data: { subject, level, goal } });

      const { data: course, error } = await supabase
        .from("courses")
        .insert({ user_id: user.id, subject, level, goal, progress: 0 })
        .select()
        .single();
      if (error) throw error;

      await supabase.from("topics").insert(
        topics.map((name, index) => ({
          course_id: course.id,
          user_id: user.id,
          name,
          position: index,
          status: index === 0 ? "in_progress" : "locked",
        })),
      );

      await supabase
        .from("profiles")
        .update({
          level,
          goal,
          daily_minutes: daily,
          learning_style: style,
          onboarded: true,
        })
        .eq("id", user.id);

      navigate({ to: "/" });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not build your plan");
    } finally {
      setBusy(false);
    }
  }

  const steps = [
    {
      title: "What do you want to learn?",
      body: (
        <input
          autoFocus
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          placeholder="e.g. Quantum mechanics, Python, Economics"
          className="w-full rounded-xl bg-paper-2 px-4 py-3.5 text-sm outline-none ring-brand/40 focus:ring-2"
        />
      ),
      valid: subject.trim().length > 1,
    },
    {
      title: "What's your current level?",
      body: (
        <div className="grid gap-2">
          {levels.map((option) => (
            <Choice key={option} active={level === option} onClick={() => setLevel(option)}>
              {option}
            </Choice>
          ))}
        </div>
      ),
      valid: true,
    },
    {
      title: "What's your goal?",
      body: (
        <input
          autoFocus
          value={goal}
          onChange={(e) => setGoal(e.target.value)}
          placeholder="e.g. Pass my exam in June"
          className="w-full rounded-xl bg-paper-2 px-4 py-3.5 text-sm outline-none ring-brand/40 focus:ring-2"
        />
      ),
      valid: true,
    },
    {
      title: "How long each day?",
      body: (
        <div className="grid grid-cols-2 gap-2">
          {minutes.map((option) => (
            <Choice key={option} active={daily === option} onClick={() => setDaily(option)}>
              {option} minutes
            </Choice>
          ))}
        </div>
      ),
      valid: true,
    },
    {
      title: "How do you learn best?",
      body: (
        <div className="grid gap-2">
          {styles.map((option) => (
            <Choice key={option} active={style === option} onClick={() => setStyle(option)}>
              {option}
            </Choice>
          ))}
        </div>
      ),
      valid: true,
    },
  ];

  const current = steps[step];

  return (
    <main className="grid min-h-screen place-items-center bg-paper px-5 py-10">
      <div className="w-full max-w-md">
        <div className="flex items-center gap-3">
          <BrandMark />
          <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
            Step {step + 1} of {steps.length}
          </p>
        </div>

        <div className="mt-6 rounded-3xl bg-card p-6 outline outline-line">
          <h1 className="font-display text-2xl font-bold tracking-tight">{current.title}</h1>
          <div className="mt-5">{current.body}</div>

          <div className="mt-6 flex items-center gap-3">
            {step > 0 ? (
              <button
                type="button"
                onClick={() => setStep(step - 1)}
                className="rounded-full bg-paper-2 px-5 py-3 font-display text-sm font-semibold text-ink"
              >
                Back
              </button>
            ) : null}
            <button
              type="button"
              disabled={!current.valid || busy}
              onClick={() => (step === steps.length - 1 ? finish() : setStep(step + 1))}
              className="flex-1 rounded-full bg-brand py-3.5 font-display text-sm font-semibold text-paper shadow-lg shadow-brand/20 disabled:opacity-50"
            >
              {busy
                ? "Building your plan…"
                : step === steps.length - 1
                  ? "Create my plan"
                  : "Continue"}
            </button>
          </div>
        </div>

        <div className="mt-4 h-2 rounded-full bg-paper-2">
          <div
            className="h-2 rounded-full bg-brand transition-all"
            style={{ width: `${((step + 1) / steps.length) * 100}%` }}
          />
        </div>
      </div>
    </main>
  );
}

function Choice({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-xl px-4 py-3 text-left text-sm font-medium transition-colors ${
        active ? "bg-brand text-paper" : "bg-paper-2 text-ink"
      }`}
    >
      {children}
    </button>
  );
}
