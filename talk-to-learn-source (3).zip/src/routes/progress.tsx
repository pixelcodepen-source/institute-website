import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { AppHeader } from "@/components/AppHeader";
import { BottomNav } from "@/components/BottomNav";
import { coursesQuery, lessonsQuery, profileQuery } from "@/lib/data";

export const Route = createFileRoute("/progress")({
  head: () => ({
    meta: [
      { title: "Your progress — Talk-to-Learn" },
      {
        name: "description",
        content:
          "See your streak, every lesson you've had, what you've mastered and what still needs practice.",
      },
      { property: "og:title", content: "Your progress — Talk-to-Learn" },
      { property: "og:description", content: "Streaks, scores, and what to revisit next." },
    ],
  }),
  component: ProgressPage,
});

function ProgressPage() {
  const navigate = useNavigate();
  const { user, loading } = useAuth();

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  const { data: profile } = useQuery({ ...profileQuery(user?.id ?? ""), enabled: !!user });
  const { data: courses } = useQuery({ ...coursesQuery(user?.id ?? ""), enabled: !!user });
  const { data: lessons } = useQuery({ ...lessonsQuery(user?.id ?? ""), enabled: !!user });

  const totalMinutes = (lessons ?? []).reduce((sum, l) => sum + l.minutes, 0);
  const avgScore = lessons?.length
    ? Math.round(
        (lessons.reduce((sum, l) => sum + (l.score ?? 0), 0) / lessons.length) * 10,
      ) / 10
    : 0;
  const weak = Array.from(new Set((lessons ?? []).flatMap((l) => l.needs_practice))).slice(0, 8);

  return (
    <main className="min-h-screen bg-paper pb-28 text-ink">
      <div className="mx-auto max-w-6xl px-6 py-8 lg:px-10">
        <AppHeader streak={profile?.streak_days} badge={profile?.level} />

        <div className="mt-9 grid grid-cols-12 gap-6">
          <section className="col-span-12 rounded-3xl bg-ink p-8 text-paper lg:col-span-7">
            <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-paper/50">
              Learning so far
            </p>
            <p className="mt-4 font-display text-4xl font-bold tracking-tight">
              {totalMinutes} minutes<span className="text-accent">.</span>
            </p>
            <div className="mt-6 grid grid-cols-3 gap-4">
              <Stat label="Streak" value={`${profile?.streak_days ?? 0}d`} />
              <Stat label="Lessons" value={`${lessons?.length ?? 0}`} />
              <Stat label="Avg score" value={`${avgScore}/10`} />
            </div>
          </section>

          <section className="col-span-12 rounded-3xl bg-card p-6 outline outline-line lg:col-span-5">
            <h2 className="font-display text-lg font-semibold tracking-tight">Needs practice</h2>
            <div className="mt-4 flex flex-wrap gap-2">
              {weak.length ? (
                weak.map((item) => (
                  <span
                    key={item}
                    className="rounded-full bg-warn/20 px-3 py-1.5 text-sm font-medium text-ink"
                  >
                    {item}
                  </span>
                ))
              ) : (
                <p className="text-sm text-ink-soft">Nothing flagged yet.</p>
              )}
            </div>
          </section>

          <section className="col-span-12 rounded-3xl bg-card p-6 outline outline-line">
            <h2 className="font-display text-lg font-semibold tracking-tight">Lesson history</h2>
            <div className="mt-4 space-y-2.5">
              {(lessons ?? []).map((lesson) => (
                <Link
                  key={lesson.id}
                  to="/lesson/$courseId"
                  params={{ courseId: lesson.course_id }}
                  className="flex items-center justify-between rounded-xl bg-paper-2 px-4 py-3"
                >
                  <div>
                    <p className="text-sm font-medium">{lesson.topic}</p>
                    <p className="font-mono text-[11px] text-muted-foreground">
                      {new Date(lesson.created_at).toLocaleDateString()} · {lesson.minutes} min
                    </p>
                  </div>
                  <span className="font-mono text-xs text-ink">{lesson.score ?? 0}/10</span>
                </Link>
              ))}
              {!lessons?.length ? (
                <p className="text-sm text-ink-soft">
                  No lessons yet — your first conversation will show up here.
                </p>
              ) : null}
            </div>
          </section>

          <section className="col-span-12 rounded-3xl bg-card p-6 outline outline-line">
            <h2 className="font-display text-lg font-semibold tracking-tight">Courses</h2>
            <div className="mt-4 space-y-2.5">
              {(courses ?? []).map((course) => (
                <div key={course.id} className="rounded-xl bg-paper-2 px-4 py-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{course.subject}</span>
                    <span className="font-mono text-xs text-muted-foreground">
                      {course.progress}%
                    </span>
                  </div>
                  <div className="mt-2 h-2 rounded-full bg-card">
                    <div
                      className="h-2 rounded-full bg-brand"
                      style={{ width: `${course.progress}%` }}
                    />
                  </div>
                </div>
              ))}
              {!courses?.length ? (
                <p className="text-sm text-ink-soft">No courses yet.</p>
              ) : null}
            </div>
          </section>
        </div>
      </div>
      <BottomNav />
    </main>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-paper/10 px-4 py-3">
      <p className="font-mono text-[10px] uppercase tracking-wider text-paper/50">{label}</p>
      <p className="mt-1 font-display text-xl font-bold">{value}</p>
    </div>
  );
}
