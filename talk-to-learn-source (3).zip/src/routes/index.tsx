import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { Play } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { AppHeader } from "@/components/AppHeader";
import { BottomNav } from "@/components/BottomNav";
import { coursesQuery, lessonsQuery, profileQuery, topicsQuery } from "@/lib/data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Talk-to-Learn — Your AI tutor, out loud" },
      {
        name: "description",
        content:
          "Your daily learning dashboard: today's goal, streak, knowledge map, and a one-tap voice lesson with your AI tutor.",
      },
      { property: "og:title", content: "Talk-to-Learn — Your AI tutor, out loud" },
      {
        property: "og:description",
        content: "Today's goal, your streak, and a one-tap voice lesson.",
      },
    ],
  }),
  component: Dashboard,
});

function greeting() {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}

function Dashboard() {
  const navigate = useNavigate();
  const { user, loading } = useAuth();

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  const { data: profile, isLoading: profileLoading } = useQuery({
    ...profileQuery(user?.id ?? ""),
    enabled: !!user,
  });
  const { data: courses } = useQuery({ ...coursesQuery(user?.id ?? ""), enabled: !!user });
  const { data: lessons } = useQuery({ ...lessonsQuery(user?.id ?? ""), enabled: !!user });

  useEffect(() => {
    if (!profileLoading && profile && !profile.onboarded) navigate({ to: "/onboarding" });
  }, [profile, profileLoading, navigate]);

  const course = courses?.[0];
  const { data: topics } = useQuery({ ...topicsQuery(course?.id ?? ""), enabled: !!course });
  const activeTopic = topics?.find((t) => t.status === "in_progress") ?? topics?.[0];
  const lastLesson = lessons?.[0];

  const now = new Date();
  const stamp = `${now.toLocaleDateString(undefined, { weekday: "short" })} · ${now.toLocaleTimeString(
    undefined,
    { hour: "numeric", minute: "2-digit" },
  )}`;

  return (
    <main className="min-h-screen w-full bg-paper pb-28 text-ink">
      <div className="mx-auto max-w-6xl px-6 py-8 lg:px-10">
        <AppHeader streak={profile?.streak_days} badge={course ? course.subject : undefined} />

        <div className="mt-9 grid grid-cols-12 gap-6">
          <div className="col-span-12 flex flex-col gap-6 lg:col-span-7">
            <section className="relative overflow-hidden rounded-3xl bg-ink p-8 text-paper">
              <div className="absolute -right-16 -top-16 size-64 rounded-full bg-brand/40 blur-3xl" />
              <div className="absolute -right-4 bottom-0 size-40 rounded-full bg-accent/25 blur-3xl" />
              <div className="relative">
                <div className="flex items-center justify-between">
                  <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-paper/50">
                    {greeting()}
                    {profile?.display_name ? `, ${profile.display_name}` : ""}
                  </p>
                  <span className="font-mono text-[11px] text-paper/60">{stamp}</span>
                </div>
                <p className="mt-5 font-display text-4xl font-bold leading-[1.05] tracking-tight sm:text-[2.75rem]">
                  Learn for{" "}
                  <span className="text-accent">{profile?.daily_minutes ?? 20} minutes</span> today
                </p>
                <p className="mt-2 max-w-md text-paper/60">
                  {course
                    ? "Your AI tutor picked up right where you left off. One conversation is all it takes."
                    : "Pick a subject and your tutor will build a conversational plan in seconds."}
                </p>
                <div className="mt-7 flex flex-wrap items-center gap-4">
                  <Link
                    to={course ? "/lesson/$courseId" : "/learn"}
                    params={course ? { courseId: course.id } : undefined}
                    className="flex items-center gap-2 rounded-full bg-accent px-6 py-3.5 font-display text-sm font-semibold text-ink shadow-lg shadow-accent/20"
                  >
                    <Play className="size-4" />
                    {course ? "Start Voice Lesson" : "Choose a subject"}
                  </Link>
                  {course && activeTopic ? (
                    <div className="rounded-2xl bg-paper/10 px-4 py-2.5 text-left">
                      <p className="font-mono text-[10px] uppercase tracking-wider text-paper/50">
                        Continue
                      </p>
                      <p className="font-display text-sm font-medium">
                        {course.subject} → {activeTopic.name}
                      </p>
                    </div>
                  ) : null}
                </div>
              </div>
            </section>

            <section className="rounded-3xl bg-card p-6 outline outline-line">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg font-semibold tracking-tight">
                  Last conversation
                </h2>
                <span className="flex items-center gap-2 rounded-full bg-accent/10 px-3 py-1.5 font-mono text-[11px] text-ink">
                  <span className="size-2 rounded-full bg-accent" />
                  {lastLesson ? `${lastLesson.minutes} min` : "No sessions yet"}
                </span>
              </div>
              {lastLesson ? (
                <div className="mt-4 space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="relative mt-0.5 grid size-9 shrink-0 place-items-center rounded-full bg-brand/10">
                      <span className="pulsering size-5 rounded-full bg-brand-2/40" />
                      <span className="pulsering-2 absolute size-5 rounded-full bg-brand-2/40" />
                    </div>
                    <div className="max-w-[85%] rounded-2xl rounded-tl-md bg-paper-2 px-4 py-3 text-sm text-ink-soft">
                      We talked about {lastLesson.topic}. You scored {lastLesson.score ?? 0}/10 — want
                      to pick it back up?
                    </div>
                  </div>
                  <div className="flex justify-end">
                    <Link
                      to="/lesson/$courseId"
                      params={{ courseId: lastLesson.course_id }}
                      className="max-w-[80%] rounded-2xl rounded-tr-md bg-brand px-4 py-3 text-sm text-paper"
                    >
                      Yes, let&apos;s keep going
                    </Link>
                  </div>
                </div>
              ) : (
                <p className="mt-4 text-sm text-ink-soft">
                  Nothing here yet. Your first spoken lesson will appear right here.
                </p>
              )}
            </section>
          </div>

          <div className="col-span-12 flex flex-col gap-6 lg:col-span-5">
            <section className="rounded-3xl bg-card p-6 outline outline-line">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg font-semibold tracking-tight">Knowledge map</h2>
                <span className="font-mono text-xs text-muted-foreground">
                  {course?.subject ?? "—"}
                </span>
              </div>
              <div className="mt-4 space-y-2.5">
                {(topics ?? []).slice(0, 6).map((topic) => (
                  <div
                    key={topic.id}
                    className="flex items-center justify-between rounded-xl bg-paper-2 px-4 py-3"
                  >
                    <span className="text-sm font-medium">{topic.name}</span>
                    <span
                      className={`font-mono text-xs ${
                        topic.status === "mastered"
                          ? "text-accent"
                          : topic.status === "in_progress"
                            ? "text-warn"
                            : topic.status === "needs_practice"
                              ? "text-rose"
                              : "text-muted-foreground"
                      }`}
                    >
                      {topic.status.replace("_", " ")}
                    </span>
                  </div>
                ))}
                {!topics?.length ? (
                  <p className="text-sm text-ink-soft">Your map appears once you pick a subject.</p>
                ) : null}
              </div>
              {course ? (
                <div className="mt-4">
                  <div className="flex items-center justify-between font-mono text-xs text-muted-foreground">
                    <span>Course progress</span>
                    <span className="text-ink">{course.progress}%</span>
                  </div>
                  <div className="mt-2 h-2 rounded-full bg-paper-2">
                    <div
                      className="h-2 rounded-full bg-brand transition-all"
                      style={{ width: `${course.progress}%` }}
                    />
                  </div>
                </div>
              ) : null}
            </section>

            <section className="rounded-3xl bg-card p-6 outline outline-line">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg font-semibold tracking-tight">Last result</h2>
                <span className="text-lg">🎉</span>
              </div>
              {lastLesson ? (
                <div className="mt-4 flex items-center gap-4">
                  <div className="grid size-16 shrink-0 place-items-center rounded-2xl bg-accent/10">
                    <span className="font-display text-xl font-bold text-ink">
                      {lastLesson.score ?? 0}/10
                    </span>
                  </div>
                  <div className="space-y-2 text-sm">
                    <p className="text-ink-soft">
                      Mastered:{" "}
                      <span className="font-semibold text-ink">
                        {lastLesson.mastered.join(", ") || "—"}
                      </span>
                    </p>
                    <p className="text-ink-soft">
                      Needs practice:{" "}
                      <span className="font-semibold text-ink">
                        {lastLesson.needs_practice.join(", ") || "—"}
                      </span>
                    </p>
                  </div>
                </div>
              ) : (
                <p className="mt-4 text-sm text-ink-soft">
                  Finish a lesson and your quiz result lands here.
                </p>
              )}
              <div className="mt-5">
                <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                  Teach from your own notes
                </p>
                <Link
                  to={course ? "/lesson/$courseId" : "/learn"}
                  params={course ? { courseId: course.id } : undefined}
                  className="mt-2 flex items-center gap-3 rounded-xl border-2 border-dashed border-line bg-paper px-4 py-3"
                >
                  <span className="grid size-9 place-items-center rounded-lg bg-brand/10 font-mono text-sm text-brand">
                    PDF
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">Upload a PDF or notes</p>
                    <p className="font-mono text-[11px] text-muted-foreground">
                      Your tutor teaches straight from it
                    </p>
                  </div>
                </Link>
              </div>
            </section>
          </div>
        </div>
      </div>
      <BottomNav />
    </main>
  );
}
