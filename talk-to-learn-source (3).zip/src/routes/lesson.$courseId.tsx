import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { Mic, Square, Send, Upload, Volume2, VolumeX } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useVoice } from "@/hooks/useVoice";
import { BrandMark } from "@/components/AppHeader";
import { coursesQuery, profileQuery, topicsQuery, touchStreak } from "@/lib/data";
import { extractFileText } from "@/lib/pdf";
import { tutorTurn, generateQuiz, gradeQuiz, type QuizQuestion } from "@/lib/tutor.functions";

export const Route = createFileRoute("/lesson/$courseId")({
  head: () => ({
    meta: [
      { title: "Voice lesson — Talk-to-Learn" },
      {
        name: "description",
        content:
          "Talk through a topic with your AI tutor, then get quizzed on what you actually understood.",
      },
      { property: "og:title", content: "Voice lesson — Talk-to-Learn" },
      { property: "og:description", content: "A calm, spoken lesson with your AI tutor." },
    ],
  }),
  component: LessonPage,
});

type Turn = { role: "user" | "assistant"; content: string };

function LessonPage() {
  const { courseId } = Route.useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { user, loading } = useAuth();
  const voice = useVoice();

  const askTutor = useServerFn(tutorTurn);
  const buildQuiz = useServerFn(generateQuiz);
  const grade = useServerFn(gradeQuiz);

  const [stage, setStage] = useState<"lesson" | "quiz" | "result">("lesson");
  const [turns, setTurns] = useState<Turn[]>([]);
  const [draft, setDraft] = useState("");
  const [thinking, setThinking] = useState(false);
  const [socratic, setSocratic] = useState(false);
  const [muted, setMuted] = useState(false);
  const [material, setMaterial] = useState<{ name: string; text: string } | null>(null);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [answers, setAnswers] = useState<string[]>([]);
  const [result, setResult] = useState<{
    score: number;
    mastered: string[];
    needsPractice: string[];
    feedback: string;
    nextTopic: string;
  } | null>(null);
  const startedAt = useRef(Date.now());
  const bootstrapped = useRef(false);
  const transcriptRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  const { data: profile } = useQuery({ ...profileQuery(user?.id ?? ""), enabled: !!user });
  const { data: courses } = useQuery({ ...coursesQuery(user?.id ?? ""), enabled: !!user });
  const { data: topics } = useQuery({ ...topicsQuery(courseId), enabled: !!user });

  const course = courses?.find((c) => c.id === courseId);
  const activeTopic = useMemo(
    () => topics?.find((t) => t.status === "in_progress") ?? topics?.[0],
    [topics],
  );

  useEffect(() => {
    transcriptRef.current?.scrollTo({ top: transcriptRef.current.scrollHeight, behavior: "smooth" });
  }, [turns, thinking]);

  async function sendTurn(history: Turn[]) {
    if (!course || !activeTopic) return;
    setThinking(true);
    try {
      const { reply } = await askTutor({
        data: {
          subject: course.subject,
          topic: activeTopic.name,
          level: course.level,
          personality: profile?.tutor_personality ?? "Friendly Teacher",
          socratic,
          material: material?.text ?? null,
          history,
        },
      });
      setTurns([...history, { role: "assistant", content: reply }]);
      if (!muted) voice.speak(reply);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "The tutor couldn't reply");
    } finally {
      setThinking(false);
    }
  }

  useEffect(() => {
    if (bootstrapped.current || !course || !activeTopic) return;
    bootstrapped.current = true;
    void sendTurn([]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [course, activeTopic]);

  function say(text: string) {
    const next: Turn[] = [...turns, { role: "user", content: text }];
    setTurns(next);
    setDraft("");
    void sendTurn(next);
  }

  async function handleUpload(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      const text = await extractFileText(file);
      if (!text.trim()) throw new Error("No readable text in that file");
      setMaterial({ name: file.name, text });
      toast.success(`${file.name} is now the source for this lesson`);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not read that file");
    }
  }

  async function endLesson() {
    if (!course || !activeTopic) return;
    voice.stopSpeaking();
    setThinking(true);
    try {
      const { questions: qs } = await buildQuiz({
        data: { subject: course.subject, topic: activeTopic.name, transcript: turns },
      });
      if (qs.length === 0) throw new Error("Quiz could not be created");
      setQuestions(qs);
      setAnswers(new Array(qs.length).fill(""));
      setStage("quiz");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not build the quiz");
    } finally {
      setThinking(false);
    }
  }

  async function submitQuiz() {
    if (!course || !activeTopic || !user) return;
    setThinking(true);
    try {
      const graded = await grade({
        data: {
          subject: course.subject,
          topic: activeTopic.name,
          answers: questions.map((q, i) => ({
            question: q.question,
            expected: q.answer,
            given: answers[i] ?? "",
          })),
        },
      });
      setResult(graded);
      setStage("result");

      const minutes = Math.max(1, Math.round((Date.now() - startedAt.current) / 60000));
      await supabase.from("lessons").insert({
        user_id: user.id,
        course_id: course.id,
        topic: activeTopic.name,
        transcript: turns,
        score: graded.score,
        mastered: graded.mastered,
        needs_practice: graded.needsPractice,
        minutes,
      });

      const passed = graded.score >= 7;
      await supabase
        .from("topics")
        .update({ status: passed ? "mastered" : "needs_practice" })
        .eq("id", activeTopic.id);

      const next = topics?.find((t) => t.position === activeTopic.position + 1);
      if (next) await supabase.from("topics").update({ status: "in_progress" }).eq("id", next.id);

      const total = topics?.length ?? 1;
      const done = (topics ?? []).filter((t) => t.status === "mastered").length + (passed ? 1 : 0);
      await supabase
        .from("courses")
        .update({ progress: Math.round((done / total) * 100) })
        .eq("id", course.id);

      if (profile) await touchStreak(profile);
      await queryClient.invalidateQueries();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not score the quiz");
    } finally {
      setThinking(false);
    }
  }

  if (!course || !activeTopic) {
    return (
      <main className="grid min-h-screen place-items-center bg-paper px-6 text-center">
        <p className="text-sm text-ink-soft">
          {loading ? "Loading your lesson…" : "This course has no topics yet."}
        </p>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-paper text-ink">
      <div className="mx-auto max-w-3xl px-6 py-8">
        <header className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BrandMark />
            <div>
              <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                {course.subject}
              </p>
              <p className="font-display text-lg font-bold leading-tight tracking-tight">
                {activeTopic.name}
              </p>
            </div>
          </div>
          <Link
            to="/"
            className="rounded-full bg-paper-2 px-4 py-2 font-mono text-xs text-ink"
            onClick={() => voice.stopSpeaking()}
          >
            Leave
          </Link>
        </header>

        {stage === "lesson" ? (
          <section className="mt-7 rounded-3xl bg-card p-6 outline outline-line">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg font-semibold tracking-tight">Live conversation</h2>
              <span className="flex items-center gap-2 rounded-full bg-accent/10 px-3 py-1.5 font-mono text-[11px] text-ink">
                <span className="size-2 rounded-full bg-accent" />
                {thinking ? "Tutor thinking" : voice.listening ? "Listening" : "Tutor ready"}
              </span>
            </div>

            <div ref={transcriptRef} className="mt-4 max-h-[46vh] space-y-3 overflow-y-auto pr-1">
              {turns.map((turn, index) =>
                turn.role === "assistant" ? (
                  <div key={index} className="flex items-start gap-3">
                    <div className="relative mt-0.5 grid size-9 shrink-0 place-items-center rounded-full bg-brand/10">
                      <span className="pulsering size-5 rounded-full bg-brand-2/40" />
                      <span className="pulsering-2 absolute size-5 rounded-full bg-brand-2/40" />
                    </div>
                    <div className="max-w-[85%] rounded-2xl rounded-tl-md bg-paper-2 px-4 py-3 text-sm text-ink-soft">
                      {turn.content}
                    </div>
                  </div>
                ) : (
                  <div key={index} className="flex justify-end">
                    <div className="max-w-[80%] rounded-2xl rounded-tr-md bg-brand px-4 py-3 text-sm text-paper">
                      {turn.content}
                    </div>
                  </div>
                ),
              )}
              {thinking ? (
                <p className="font-mono text-[11px] text-muted-foreground">Tutor is thinking…</p>
              ) : null}
            </div>

            <div className="mt-5 flex items-center gap-2">
              <input
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && draft.trim()) say(draft.trim());
                }}
                placeholder={voice.supported ? "Speak, or type your answer" : "Type your answer"}
                className="flex-1 rounded-full bg-paper-2 px-4 py-3 text-sm outline-none ring-brand/40 focus:ring-2"
              />
              <button
                type="button"
                aria-label="Send"
                disabled={!draft.trim() || thinking}
                onClick={() => say(draft.trim())}
                className="grid size-11 place-items-center rounded-full bg-paper-2 text-ink disabled:opacity-40"
              >
                <Send className="size-4" />
              </button>
              <button
                type="button"
                aria-label={voice.listening ? "Stop listening" : "Speak"}
                disabled={thinking || !voice.supported}
                onClick={() => (voice.listening ? voice.stopListening() : voice.listen(say))}
                className={`grid size-14 place-items-center rounded-full shadow-xl transition-colors disabled:opacity-40 ${
                  voice.listening ? "bg-brand text-paper shadow-brand/30" : "bg-ink text-paper shadow-ink/20"
                }`}
              >
                {voice.listening ? <Square className="size-5" /> : <Mic className="size-5" />}
              </button>
            </div>

            <div className="mt-5 flex flex-wrap items-center gap-2 font-mono text-[11px] text-muted-foreground">
              <button
                type="button"
                onClick={() => setSocratic(!socratic)}
                className={`rounded-full px-3 py-2 ${socratic ? "bg-brand text-paper" : "bg-paper-2 text-ink"}`}
              >
                Socratic mode {socratic ? "on" : "off"}
              </button>
              <button
                type="button"
                onClick={() => {
                  setMuted(!muted);
                  voice.stopSpeaking();
                }}
                className="flex items-center gap-1.5 rounded-full bg-paper-2 px-3 py-2 text-ink"
              >
                {muted ? <VolumeX className="size-3.5" /> : <Volume2 className="size-3.5" />}
                {muted ? "Voice off" : "Voice on"}
              </button>
              <label className="flex cursor-pointer items-center gap-1.5 rounded-full bg-paper-2 px-3 py-2 text-ink">
                <Upload className="size-3.5" />
                {material ? material.name.slice(0, 22) : "Upload material"}
                <input
                  type="file"
                  accept=".pdf,.txt,.md"
                  className="hidden"
                  onChange={handleUpload}
                />
              </label>
              <button
                type="button"
                disabled={turns.length < 2 || thinking}
                onClick={endLesson}
                className="ml-auto rounded-full bg-accent px-4 py-2 font-display text-xs font-semibold text-ink disabled:opacity-40"
              >
                End &amp; quiz me
              </button>
            </div>

            {!voice.supported ? (
              <p className="mt-3 font-mono text-[11px] text-muted-foreground">
                Speaking isn&apos;t supported in this browser — typing works just as well.
              </p>
            ) : null}
          </section>
        ) : null}

        {stage === "quiz" ? (
          <section className="mt-7 rounded-3xl bg-card p-6 outline outline-line">
            <h2 className="font-display text-xl font-bold tracking-tight">Quick check</h2>
            <p className="mt-1 text-sm text-ink-soft">Five questions on what we just talked about.</p>
            <div className="mt-5 space-y-5">
              {questions.map((q, index) => (
                <div key={index}>
                  <p className="text-sm font-medium">
                    {index + 1}. {q.question}
                  </p>
                  {q.type === "multiple_choice" && q.options?.length ? (
                    <div className="mt-2 grid gap-2">
                      {q.options.map((option) => (
                        <button
                          key={option}
                          type="button"
                          onClick={() => {
                            const next = [...answers];
                            next[index] = option;
                            setAnswers(next);
                          }}
                          className={`rounded-xl px-4 py-3 text-left text-sm ${
                            answers[index] === option ? "bg-brand text-paper" : "bg-paper-2 text-ink"
                          }`}
                        >
                          {option}
                        </button>
                      ))}
                    </div>
                  ) : (
                    <textarea
                      value={answers[index] ?? ""}
                      onChange={(e) => {
                        const next = [...answers];
                        next[index] = e.target.value;
                        setAnswers(next);
                      }}
                      rows={3}
                      className="mt-2 w-full rounded-xl bg-paper-2 px-4 py-3 text-sm outline-none ring-brand/40 focus:ring-2"
                      placeholder="Explain in your own words"
                    />
                  )}
                </div>
              ))}
            </div>
            <button
              type="button"
              disabled={thinking}
              onClick={submitQuiz}
              className="mt-6 w-full rounded-full bg-brand py-3.5 font-display text-sm font-semibold text-paper shadow-lg shadow-brand/20 disabled:opacity-50"
            >
              {thinking ? "Marking…" : "Submit answers"}
            </button>
          </section>
        ) : null}

        {stage === "result" && result ? (
          <section className="mt-7 rounded-3xl bg-card p-6 outline outline-line">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl font-bold tracking-tight">Lesson complete</h2>
              <span className="text-lg">🎉</span>
            </div>
            <div className="mt-4 flex items-center gap-4">
              <div className="grid size-16 shrink-0 place-items-center rounded-2xl bg-accent/10">
                <span className="font-display text-xl font-bold text-ink">{result.score}/10</span>
              </div>
              <p className="text-sm text-ink-soft">{result.feedback}</p>
            </div>

            <div className="mt-5">
              <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                Mastered
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                {result.mastered.length ? (
                  result.mastered.map((item) => (
                    <span
                      key={item}
                      className="rounded-full bg-accent/15 px-3 py-1.5 text-sm font-medium text-ink"
                    >
                      {item}
                    </span>
                  ))
                ) : (
                  <span className="text-sm text-ink-soft">Nothing locked in yet — keep going.</span>
                )}
              </div>
            </div>

            <div className="mt-4">
              <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                Needs practice
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                {result.needsPractice.length ? (
                  result.needsPractice.map((item) => (
                    <span
                      key={item}
                      className="rounded-full bg-warn/20 px-3 py-1.5 text-sm font-medium text-ink"
                    >
                      {item}
                    </span>
                  ))
                ) : (
                  <span className="text-sm text-ink-soft">Nothing flagged. Nicely done.</span>
                )}
              </div>
            </div>

            <div className="mt-6 flex gap-3">
              <button
                type="button"
                onClick={() => window.location.reload()}
                className="flex-1 rounded-full bg-brand py-3.5 font-display text-sm font-semibold text-paper"
              >
                Next: {result.nextTopic || "keep learning"}
              </button>
              <Link
                to="/"
                className="rounded-full bg-paper-2 px-5 py-3.5 font-display text-sm font-semibold text-ink"
              >
                Home
              </Link>
            </div>
          </section>
        ) : null}
      </div>
    </main>
  );
}
