import { supabase } from "@/integrations/supabase/client";

export type Profile = {
  id: string;
  display_name: string | null;
  level: string;
  goal: string | null;
  daily_minutes: number;
  learning_style: string | null;
  tutor_personality: string;
  streak_days: number;
  last_active_date: string | null;
  onboarded: boolean;
};

export type Course = {
  id: string;
  subject: string;
  level: string;
  goal: string | null;
  progress: number;
  created_at: string;
};

export type Topic = {
  id: string;
  course_id: string;
  name: string;
  position: number;
  status: string;
};

export type Lesson = {
  id: string;
  course_id: string;
  topic: string;
  score: number | null;
  mastered: string[];
  needs_practice: string[];
  minutes: number;
  created_at: string;
};

export const profileQuery = (userId: string) => ({
  queryKey: ["profile", userId],
  queryFn: async (): Promise<Profile | null> => {
    const { data, error } = await supabase.from("profiles").select("*").eq("id", userId).maybeSingle();
    if (error) throw error;
    return data as Profile | null;
  },
});

export const coursesQuery = (userId: string) => ({
  queryKey: ["courses", userId],
  queryFn: async (): Promise<Course[]> => {
    const { data, error } = await supabase
      .from("courses")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data ?? []) as Course[];
  },
});

export const topicsQuery = (courseId: string) => ({
  queryKey: ["topics", courseId],
  queryFn: async (): Promise<Topic[]> => {
    const { data, error } = await supabase
      .from("topics")
      .select("*")
      .eq("course_id", courseId)
      .order("position");
    if (error) throw error;
    return (data ?? []) as Topic[];
  },
});

export const lessonsQuery = (userId: string) => ({
  queryKey: ["lessons", userId],
  queryFn: async (): Promise<Lesson[]> => {
    const { data, error } = await supabase
      .from("lessons")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(20);
    if (error) throw error;
    return (data ?? []) as Lesson[];
  },
});

export async function touchStreak(profile: Profile) {
  const today = new Date().toISOString().slice(0, 10);
  if (profile.last_active_date === today) return profile.streak_days;
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  const next = profile.last_active_date === yesterday ? profile.streak_days + 1 : 1;
  await supabase
    .from("profiles")
    .update({ streak_days: next, last_active_date: today })
    .eq("id", profile.id);
  return next;
}
