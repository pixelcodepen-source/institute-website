import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { gatewayChat, type ChatMessage } from "./ai.server";

const personaStyles: Record<string, string> = {
  "Friendly Teacher": "warm, encouraging, uses everyday analogies",
  "Strict Professor": "precise, demanding, expects rigour but stays fair",
  "Patient Tutor": "slow, gentle, breaks everything into small steps",
  "Socratic Tutor": "never gives the answer directly, only guiding questions",
  "Study Buddy": "casual peer, thinks out loud alongside the student",
};

function tutorSystemPrompt(input: {
  subject: string;
  topic: string;
  level: string;
  personality: string;
  socratic: boolean;
  material?: string | null;
}) {
  return [
    `You are a personal voice tutor teaching ${input.subject}, currently on the topic "${input.topic}".`,
    `The student's level is ${input.level}. Your teaching style: ${personaStyles[input.personality] ?? personaStyles["Friendly Teacher"]}.`,
    "Rules:",
    "- Speak conversationally, as if talking out loud. Keep each turn under 70 words.",
    "- Ask a question in almost every turn and wait for the student's answer.",
    "- Detect misunderstandings and never repeat the same explanation twice; switch analogy or approach.",
    "- If the student answers well, raise difficulty and move forward. If they struggle, simplify and give an example.",
    "- Prioritise understanding over memorisation. Use plain language.",
    input.socratic
      ? "- SOCRATIC MODE: never state the answer outright. Guide only with questions and hints."
      : "- Give clear explanations, but let the student reason first.",
    input.material
      ? `Teach strictly from this study material the student uploaded:\n"""${input.material.slice(0, 12000)}"""`
      : "",
  ]
    .filter(Boolean)
    .join("\n");
}

const TurnInput = z.object({
  subject: z.string().min(1),
  topic: z.string().min(1),
  level: z.string().default("Beginner"),
  personality: z.string().default("Friendly Teacher"),
  socratic: z.boolean().default(false),
  material: z.string().nullable().optional(),
  history: z
    .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() }))
    .default([]),
});

export const tutorTurn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => TurnInput.parse(data))
  .handler(async ({ data }) => {
    const messages: ChatMessage[] = [
      { role: "system", content: tutorSystemPrompt(data) },
      ...data.history,
    ];
    if (data.history.length === 0) {
      messages.push({
        role: "user",
        content: `Start the lesson on "${data.topic}" with a friendly greeting and one opening question.`,
      });
    }
    const reply = await gatewayChat(messages);
    return { reply: reply.trim() };
  });

const PlanInput = z.object({
  subject: z.string().min(1),
  level: z.string().default("Beginner"),
  goal: z.string().optional().nullable(),
});

export const generatePlan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => PlanInput.parse(data))
  .handler(async ({ data }) => {
    const raw = await gatewayChat(
      [
        {
          role: "system",
          content:
            "You design short learning plans. Reply as json with a single key 'topics': an ordered list of 6 to 8 short topic names (2-4 words each), easiest first.",
        },
        {
          role: "user",
          content: `Subject: ${data.subject}. Level: ${data.level}. Goal: ${data.goal ?? "general understanding"}. Return json.`,
        },
      ],
      { json: true },
    );
    let topics: string[] = [];
    try {
      const parsed = JSON.parse(raw) as { topics?: unknown };
      if (Array.isArray(parsed.topics)) {
        topics = parsed.topics.filter((t): t is string => typeof t === "string").slice(0, 8);
      }
    } catch {
      topics = [];
    }
    if (topics.length === 0) topics = ["Getting started", "Core ideas", "Practice", "Going deeper"];
    return { topics };
  });

const QuizInput = z.object({
  subject: z.string().min(1),
  topic: z.string().min(1),
  transcript: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() })),
});

export type QuizQuestion = {
  type: "multiple_choice" | "short_answer" | "application";
  question: string;
  options: string[];
  answer: string;
};

export const generateQuiz = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => QuizInput.parse(data))
  .handler(async ({ data }) => {
    const convo = data.transcript
      .slice(-24)
      .map((m) => `${m.role === "user" ? "Student" : "Tutor"}: ${m.content}`)
      .join("\n");
    const raw = await gatewayChat(
      [
        {
          role: "system",
          content:
            "You write short end-of-lesson quizzes. Reply as json with key 'questions': a list of 5 items. Each item has 'type' (multiple_choice, short_answer or application), 'question', 'options' (4 strings for multiple_choice, otherwise an empty list) and 'answer' (the correct answer or a model answer). Include at least three multiple_choice, one short_answer and one application question.",
        },
        {
          role: "user",
          content: `Subject: ${data.subject}. Topic: ${data.topic}.\nLesson conversation:\n${convo}\nReturn json.`,
        },
      ],
      { json: true },
    );
    let questions: QuizQuestion[] = [];
    try {
      const parsed = JSON.parse(raw) as { questions?: QuizQuestion[] };
      if (Array.isArray(parsed.questions)) questions = parsed.questions.slice(0, 5);
    } catch {
      questions = [];
    }
    return { questions };
  });

const GradeInput = z.object({
  subject: z.string(),
  topic: z.string(),
  answers: z.array(z.object({ question: z.string(), expected: z.string(), given: z.string() })),
});

export const gradeQuiz = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => GradeInput.parse(data))
  .handler(async ({ data }) => {
    const raw = await gatewayChat(
      [
        {
          role: "system",
          content:
            "You grade a short quiz generously but honestly. Reply as json with keys: 'score' (integer 0-10), 'mastered' (list of short concept names the student clearly understood), 'needs_practice' (list of short concept names to revisit), 'feedback' (two sentences), 'next_topic' (a short topic name to learn next).",
        },
        {
          role: "user",
          content: `Subject: ${data.subject}. Topic: ${data.topic}.\n${data.answers
            .map(
              (a, i) =>
                `Q${i + 1}: ${a.question}\nExpected: ${a.expected}\nStudent: ${a.given || "(no answer)"}`,
            )
            .join("\n\n")}\nReturn json.`,
        },
      ],
      { json: true },
    );
    try {
      const parsed = JSON.parse(raw) as {
        score?: number;
        mastered?: string[];
        needs_practice?: string[];
        feedback?: string;
        next_topic?: string;
      };
      return {
        score: Math.max(0, Math.min(10, Math.round(Number(parsed.score ?? 0)))),
        mastered: (parsed.mastered ?? []).slice(0, 5),
        needsPractice: (parsed.needs_practice ?? []).slice(0, 5),
        feedback: parsed.feedback ?? "",
        nextTopic: parsed.next_topic ?? "",
      };
    } catch {
      return {
        score: 0,
        mastered: [] as string[],
        needsPractice: [] as string[],
        feedback: "We couldn't score this session, but the conversation still counts.",
        nextTopic: "",
      };
    }
  });
