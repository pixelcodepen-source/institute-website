import { Link, useRouterState } from "@tanstack/react-router";
import { Home, GraduationCap, TrendingUp, User } from "lucide-react";

const items = [
  { to: "/", label: "Home", Icon: Home },
  { to: "/learn", label: "Learn", Icon: GraduationCap },
  { to: "/progress", label: "Progress", Icon: TrendingUp },
  { to: "/profile", label: "Profile", Icon: User },
] as const;

export function BottomNav() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <nav className="fixed bottom-0 left-1/2 z-20 w-full max-w-md -translate-x-1/2 px-4 pb-4">
      <div className="flex items-center justify-between rounded-full bg-ink/95 px-3 py-3 shadow-2xl shadow-ink/30 backdrop-blur">
        {items.map(({ to, label, Icon }) => {
          const active = to === "/" ? pathname === "/" : pathname.startsWith(to);
          return (
            <Link
              key={to}
              to={to}
              aria-label={label}
              className={`grid flex-1 place-items-center rounded-full py-2.5 transition-colors ${
                active ? "bg-paper/10 text-paper" : "text-paper/50"
              }`}
            >
              <Icon className="size-5" strokeWidth={2} />
              <span className="sr-only">{label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
