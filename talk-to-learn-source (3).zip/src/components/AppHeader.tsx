import { Flame } from "lucide-react";

export function BrandMark() {
  return (
    <div className="grid size-11 place-items-center rounded-2xl bg-brand shadow-lg shadow-brand/30">
      <div className="flex h-5 items-end gap-[3px]">
        <span className="eq1 w-[3px] rounded-full bg-paper" />
        <span className="eq2 w-[3px] rounded-full bg-paper" />
        <span className="eq3 w-[3px] rounded-full bg-paper" />
        <span className="eq4 w-[3px] rounded-full bg-paper" />
        <span className="eq5 w-[3px] rounded-full bg-paper" />
      </div>
    </div>
  );
}

export function AppHeader({ streak, badge }: { streak?: number; badge?: string }) {
  return (
    <header className="flex items-center justify-between">
      <div className="flex items-center gap-3">
        <BrandMark />
        <div>
          <p className="font-display text-lg font-bold leading-none tracking-tight">Talk-to-Learn</p>
          <p className="font-mono text-[11px] text-muted-foreground">
            Don&apos;t study. Have a conversation.
          </p>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1.5 rounded-full bg-accent/10 px-3.5 py-2 font-mono text-xs font-medium text-ink">
          <Flame className="size-4 text-warn" />
          {streak ?? 0}-day streak
        </div>
        {badge ? (
          <div className="hidden rounded-full bg-card px-4 py-2 font-mono text-xs text-muted-foreground outline outline-line sm:block">
            {badge}
          </div>
        ) : null}
      </div>
    </header>
  );
}
